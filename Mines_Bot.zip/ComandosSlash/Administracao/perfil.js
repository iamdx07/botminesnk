const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder, PermissionFlagsBits } = require("discord.js");
const { economia } = require("../../DataBaseJson");
const Discord = require("discord.js");
const config = require('../../config.json')

module.exports = {
  name: "painel-mines",
  description: "sete o painel mines",
  type: ApplicationCommandType.ChatInput,
  defaultMemberPermissions: PermissionFlagsBits.Administrator,



  run: async (client, interaction, message) => {


    const embed = new EmbedBuilder()
      .setColor(`#2f3136`)
      .setTitle(` Mines 💣`)
      .setDescription(`- Verifique sempre os termos e condições para garantir uma experiência tranquila.\n- Jogar com responsabilidade é fundamental para uma experiência positiva.`)

      const depositar = new ButtonBuilder()
      .setCustomId(`depositarmoney`)
      .setEmoji(`<:saldo:1185061994844393544>`)
      .setStyle(3)
      .setDisabled(config.perfil)
      .setLabel('Depositar');
	  
      const jogar = new ButtonBuilder()
      .setCustomId(`cronoz`)
      .setEmoji(`<:play:1186657469481631754>`)
      .setStyle(2)
      .setDisabled(false)
      .setLabel('Jogar');

      const perfil = new ButtonBuilder()
      .setCustomId(`perfil`)
      .setEmoji(`<:perfil:1185062494822203422>`)
      .setStyle(2)
      .setDisabled(false)
      .setLabel('Perfil');


      const sacar = new ButtonBuilder()
      .setCustomId(`sacarmoney`)
      .setEmoji(`<:saldo:1185061994844393544>`)
      .setStyle(4)
      .setDisabled(false)
      .setLabel('Sacar');

      const novoBotaoRow = new ActionRowBuilder().addComponents(jogar, perfil, depositar, sacar);

    interaction.channel.send({ embeds: [embed], components: [novoBotaoRow] })
  }
}
