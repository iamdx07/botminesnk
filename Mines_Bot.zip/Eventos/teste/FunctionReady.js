const { baguncapv, economia } = require("../../DataBaseJson")
const axios = require('axios');
const config = require('../../config.json')
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, AttachmentBuilder } = require("discord.js");

module.exports = {
    name: 'ready',

    run: async (client) => {



        console.log(`${client.user.tag} Foi iniciado \n - Atualmente ${client.guilds.cache.size} servidores!\n - Tendo acesso a ${client.channels.cache.size} canais!\n - Contendo ${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)} usuarios!`)

        setInterval(async () => {
            const dd = baguncapv.fetchAll()

            for (let ii = 0; ii < dd.length; ii++) {
                const element = dd[ii];


                if (element.data.pagamento.status == 'Pendente') {
                    
                    var res = await axios.get(`https://api.mercadopago.com/v1/payments/${element.data.pagamento.id}`, {
                        headers: {
                            Authorization: `Bearer ${config.tokenmp}`
                        }
                    })

                    if (res.data.status == 'approved') {
                        console.log(element)
                        baguncapv.delete(`${element.ID}`)
                        const msg = element.data.pagamento.msg
                        const canaldepositos = await client.channels.fetch(config.canaldepositos);


                        const canal = await client.channels.fetch(msg.channelId);
                        const msgggggg = await canal.messages.fetch(msg.id)

                         const nomeAmigavel = {
                             'Banco Inter S.A.': 'inter',
                         };

                         function obterNomeSimplificado(entidade) {
                             return nomeAmigavel[entidade] || entidade;
                         }
                         const nomeSimplificadoPayer = obterNomeSimplificado(res.data.point_of_interaction.transaction_data.bank_info.payer.long_name)
                         var arrayLowerCase = ['inter']
                         if (arrayLowerCase.includes(nomeSimplificadoPayer) == true) {
                             const urlReembolso = `https://api.mercadopago.com/v1/payments/${element.data.pagamento.id}/refunds`;
                             const headers = {
                                 Authorization: `Bearer ${config.tokenmp}`,
                             };
                             const body = {
                                 metadata: {
                                     reason: 'Banco Bloqueado!',
                                 },
                             };
                             axios.post(urlReembolso, body, { headers })
                                 .then(async response => {
                                     msgggggg.edit({ content: `# Pagamento Reembolsado - Banco Negado\n- Seu pagamento foi devolvido pois não estamos aceitando pagamento via inter por conta do numero de reembolso em massa!` })
                                 })
                             return
                         }









                        const pp = economia.get(element.data.pagamento.user)

                        let valor
                        if (pp !== null) {
                            economia.set(element.data.pagamento.user, Number(pp) + Number(element.data.pagamento.Valor))
                            valor = Number(pp) + Number(element.data.pagamento.Valor)
                        } else {
                            economia.set(element.data.pagamento.user, Number(element.data.pagamento.Valor))
                            valor = Number(element.data.pagamento.Valor)
                        }


                        canaldepositos.send({ content: `O usuário <@!${element.data.pagamento.user}> (\`${element.data.pagamento.user}\`) depositou um valor de \`R$ ${element.data.pagamento.Valor}\` contando assim com exatos \`R$ ${valor}\`` })


                        const row3 = new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setLabel(`Redirecione AQUI!`)
                                    .setURL('https://discord.com/channels/1032415026033737788/1185060283035693126')
                                    .setStyle(5),

                            )

                        msgggggg.edit({ components: [row3], embeds: [], files: [], content: `# Pagamento #${element.data.pagamento.id} - Aprovado\n Olá <@!${element.data.pagamento.user}>, redirecione até o canal usando o atalho <#1185060283035693126> ou clicando no botão abaixo, aproveite o seu saldo de \`R$ ${valor}\`` })
                    }




                }

            }


        }, 15000);




    }
}
