const { GatewayIntentBits, Client, Collection, ChannelType } = require("discord.js");
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.DirectMessages,
    ]
});
const config = require("./config.json");
const events = require('./Handler/events');
const slash = require('./Handler/slash');

slash.run(client);
events.run(client);

client.slashCommands = new Collection();

const { ActionRowBuilder, ButtonBuilder } = require('discord.js');
const fs = require('fs');

const PREFIX = '!'; // Prefixo para comandos

client.once('ready', () => {
    console.log('Bot está online!');
});

client.on('messageCreate', message => {
    if (message.author.bot) return;
    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === 'config') {
        if (!message.member.permissions.has('ADMINISTRATOR')) {
            message.channel.send('Você não pode usar esse comando');
            return;
        }
        sendConfigPanel(message);
    }
});

function sendConfigPanel(message) {
    const configRow = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('config_tokenmp')
                .setLabel('Configurar token do mercado pago')
                .setStyle('Danger'),
            new ButtonBuilder()
                .setCustomId('config_canalsaques')
                .setLabel('Configurar canal de logs de saques')
                .setStyle('Success'),
            new ButtonBuilder()
                .setCustomId('config_canalresgatou')
                .setLabel('Configurar canal de logs de resgate')
                .setStyle('Success'),
        );
    const configRowdois = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('config_canalperdeu')
                .setLabel('Configurar canal de logs de derrotas')
                .setStyle('Success'),
            new ButtonBuilder()
                .setCustomId('config_canaldepositos')
                .setLabel('Configurar canal de logs de depósitos')
                .setStyle('Success'),
            new ButtonBuilder()
                .setCustomId('config_canalcomecou')
                .setLabel('Configurar canal de logs de jogo')
                .setStyle('Success')
        );

    message.channel.send({ content: ``, components: [configRow, configRowdois], ephemeral: true });

    const filter = i => i.customId.startsWith('config') && i.user.id === message.author.id;

    const collector = message.channel.createMessageComponentCollector({ filter, time: 15000 });

    collector.on('collect', async interaction => {
        let configFile = {};
        try {
            configFile = JSON.parse(fs.readFileSync('config.json', 'utf8'));
        } catch (error) {
            console.error('Erro ao ler o arquivo de configuração:', error);
        }

        const buttonId = interaction.customId;
        const configKey = buttonId.split('_')[1];

        await interaction.reply({ content: `Por favor, envie o novo valor para ${configKey}:`, ephemeral: true });

        const messageCollector = message.channel.createMessageCollector({ filter: m => m.author.id === message.author.id, max: 1, time: 15000 });

        messageCollector.on('collect', m => {
            configFile[configKey] = m.content;
            fs.writeFileSync('config.json', JSON.stringify(configFile, null, 2));
            interaction.followUp(`Valor de ${configKey} alterado para ${m.content}`);
        });

        messageCollector.on('end', collected => {
            if (collected.size === 0) {
                interaction.followUp('Tempo esgotado. Tente novamente.');
            }
        });
    });
}

client.login(config.token);

// unhandledRejection
process.on("unhandledRejection", (reason, promise) => {
    console.error(reason + " " + promise);
    return;
});

// uncaughtException
process.on("uncaughtException", (error, origin) => {
    console.error(error + " " + origin);
    return;
});